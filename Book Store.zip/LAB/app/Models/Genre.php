<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Genre extends Model
{
    use HasFactory;
    public $timestamps = false;
    
    protected $table = 'genres';

    protected $fillable = [
        'name',
    ];

    protected $guarded = [];

    public function bookgenres() {
        return $this->hasMany(Bookgenre::class, 'genre_id', 'id');
    }
}
