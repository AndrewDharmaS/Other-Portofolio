<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

use App\Models\User;
use App\Models\Book;
use App\Models\Genre;
use App\Models\Order;
use App\Models\Bookgenre;
use App\Models\Transaction;
use Illuminate\Support\Facades\Storage;

class TransactionController extends Controller
{
    //
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function create() {
        $user = Auth::user();
        $orders = $user->orders;
        if ($orders != null || $orders->isNotEmpty()) {
            $transaction = new Transaction();
            $transaction->user_id = $user->id;
            $transaction->transaction_id = (date('His') << date('d')).'-'.uniqid().'-'.(date('Ymds') << date('d')-1);
            $array = [];
            foreach($orders as $order) {
                $str = ['id' => $order->book->id, 'name' => $order->book->name, 'author' => $order->book->author, 'price' => $order->book->price, 'quantity' => $order->quantity];
                array_push($array, $str);
                $order->delete();
            }
            $transaction->cart = serialize($array);
            $transaction->save();
            return redirect()->route('transaction-view');
        } else {
            return redirect()->back();
        }
    }
    public function detail($id) {
        $transaction = Transaction::find($id);
        $transaction->cart = unserialize($transaction->cart);
        return view('auth.member.transaction-detail', compact(['transaction']));
    }
    public function view() {
        $user = Auth::user();
        $transactions = $user->transactions;
        foreach($transactions as $transaction) $transaction->cart = unserialize($transaction->cart);
        return view('auth.member.transaction', compact(['transactions']));
    }
}
