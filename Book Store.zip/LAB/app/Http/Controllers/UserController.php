<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

use App\Models\User;
use App\Models\Book;
use App\Models\Genre;
use App\Models\Order;
use App\Models\Bookgenre;
use App\Models\Transaction;
use Illuminate\Support\Facades\Storage;

class UserController extends Controller
{
    //
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }
    public function profile() {
        $user = Auth::user();
        return view('auth.profile', compact(['user']));
    }
    public function profileUpdate(Request $request) {
        $request->validate([
            'name' => 'required|max:255',
        ]);
        $user = Auth::user();
        $user->name = $request->name;
        $user->save();
        return redirect()->route('user-profile');
    }
    public function changePasswordView() {
        return view('auth.profile-password');
    }
    public function changePassword(Request $request) {
        $request->validate([
            'oldpassword' => 'required|max:255',
            'password' => 'required|min:8|max:255|different:oldpassword|confirmed',
        ]);
        $user = Auth::user();
        if (Hash::check($request->oldpassword, $user->password)) {
            $user->password = Hash::make($request->password);
            $user->save();
            return redirect()->route('user-profile');
        } else {
            return redirect()->back()->with(['status' => 'Current password incorrect!']);
        }
    }
    
    public function manageUser() {
        $users = User::all();
        return view('auth.admin.user-manage', compact(['users']));
    }
    public function updateView($id) {
        $user = User::find($id);
        return view('auth.admin.user-detail', compact(['user']));
    }
    public function update(Request $request, $id) {
        $rolecheck = ['admin', 'member'];
        $request->validate([
            'name' => 'required|max:255',
            'email' => 'sometimes|required|max:255|email|unique:users,email,'.$id,
            'role' => 'required|max:255|in:'.implode(",", $rolecheck),
        ]);
        $user = User::find($id);
        $user->name = $request->name;
        $user->email = $request->email;
        $user->role = $request->role;
        $user->save();
        return redirect()->route('user-manage');
    }
    public function delete($id) {
        $user = User::find($id);
        if ($user->role != 'admin') {
            foreach($user->transactions as $t) $t->delete();
            foreach($user->orders as $o) $o->delete();
            $user->delete();
        }
        return redirect()->route('user-manage');
    }
}
