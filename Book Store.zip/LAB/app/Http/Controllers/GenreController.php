<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

use App\Models\User;
use App\Models\Book;
use App\Models\Genre;
use App\Models\Order;
use App\Models\Bookgenre;
use App\Models\Transaction;
use Illuminate\Support\Facades\Storage;

class GenreController extends Controller
{
    //
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }
    public function manageGenre() {
        $genres = Genre::all();
        return view('auth.admin.genre-manage', compact(['genres']));
    }
    public function create(Request $request) {
        $request->validate([
            'name' => 'required|max:255|unique:genres,name',
        ]);
        $genre = new Genre();
        $genre->name = $request->name;
        $genre->save();

        return redirect()->route('genre-manage');
    }
    public function updateView($id) {
        $genre = Genre::find($id);
        return view('auth.admin.genre-detail', compact(['genre']));
    }
    public function update(Request $request, $id) {
        $request->validate([
            'name' => 'required|max:255|unique:genres,name,'.$id,
        ]);
        $genre = Genre::find($id);
        $genre->name = $request->name;
        $genre->save();
        return redirect()->route('genre-manage');
    }
    public function delete($id) {
        $genre = Genre::find($id);
        foreach($genre->bookgenres as $bg) $bg->delete();
        $genre->delete();
        return redirect()->route('genre-manage');
    }
}
