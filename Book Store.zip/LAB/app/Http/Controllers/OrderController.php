<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

use App\Models\User;
use App\Models\Book;
use App\Models\Genre;
use App\Models\Order;
use App\Models\Bookgenre;
use App\Models\Transaction;
use Illuminate\Support\Facades\Storage;

class OrderController extends Controller
{
    //
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }
    public function cart() {
        $user = Auth::user();
        $orders = $user->orders;
        return view('auth.member.cart', compact('orders'));
    }
    public function create(Request $request, $id) {
        $request->validate([
            'quantity' => 'required|min:1',
        ]);
        $user = Auth::user();
        $book = Book::find($id);
        $orders = $user->orders;
        if ($orders != null) {
            foreach ($orders as $o) {
                if ($o->book_id == $id) {
                    $o->quantity += $request->quantity;
                    $o->save();
                    return redirect()->route('cart-view');
                }
            }
        }
        
        $order = new Order();
        $order->user_id = $user->id;
        $order->book_id = $book->id;
        $order->quantity = $request->quantity;
        $order->save();
        return redirect()->route('cart-view');
    }
    
    public function delete($id) {
        $order = Order::find($id);
        $order->delete();
        return redirect()->route('cart-view');
    }

    public function updateView($id) {
        $order = Order::find($id);
        return view('auth.member.order-update', compact('order'));
    }

    public function update(Request $request, $id) {
        $request->validate([
            'quantity' => 'required|min:1',
        ]);
        $order = Order::find($id);
        $order->quantity = $request->quantity;
        $order->save();
        return redirect()->route('cart-view');
    }
}
