<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

use App\Models\User;
use App\Models\Book;
use App\Models\Genre;
use App\Models\Order;
use App\Models\Bookgenre;
use App\Models\Transaction;
use Illuminate\Support\Facades\Storage;

class BookController extends Controller
{
    //
    public function view($id) {
        $book = Book::find($id);
        return view('book', compact(['book']));
    }
    public function search(Request $request) {
        $request->validate([
            'search' => 'nullable|max:255',
        ]);
        $search = $request->search;
        $books = Book::where([
            ['name', '!=', NULL],
            [function ($query) use ($search) {
                $query->orWhere('name', 'LIKE', '%'.$search.'%');
            }]
        ])->orderBy('id', 'desc')->paginate(5);
        return view('search', compact(['books', 'search']));
    }
    public function manageBook() {
        $books = Book::all();
        $genres = Genre::all();
        return view('auth.admin.book-manage', compact(['books', 'genres']));
    }
    public function create(Request $request) {
        $request->validate([
            'name' => 'required|max:255',
            'author' => 'required|max:255',
            'synopsis' => 'required',
            'genre' => 'required|min:1|exists:genres,id',
            'price' => 'required|integer',
            'image' => 'required|image|mimes:jpg,jpeg,png,svg',
        ]);
        $book = new Book();
        $book->name = $request->name;
        $book->author = $request->author;
        $book->synopsis = $request->synopsis;
        $book->price = $request->price;
        $file = $request->file('image');
		$image = time()."_".$file->getClientOriginalName();
        Storage::putFileAs('public/images', $file, $image);
        $book->image = 'images/'.$image;
        $book->save();
        foreach ($request->genre as $g) {
            $bookgenre = new Bookgenre();
            $bookgenre->genre_id = $g;
            $bookgenre->book_id = $book->id;
            $bookgenre->save();
        }

        return redirect()->route('book-manage');
    }
    public function updateView($id) {
        $book = Book::find($id);
        $bookgenre = $book->bookgenres;
        $genres = Genre::all();
        return view('auth.admin.book-update', compact(['book', 'genres', 'bookgenre']));
    }
    public function update(Request $request, $id) {
        $request->validate([
            'name' => 'required|max:255',
            'author' => 'required|max:255',
            'synopsis' => 'required',
            'genre' => 'required|min:1|exists:genres,id',
            'price' => 'required|integer',
            'image' => 'sometimes|required|image|mimes:jpg,jpeg,png,svg',
        ]);
        $book = Book::find($id);
        $book->name = $request->name;
        $book->author = $request->author;
        $book->synopsis = $request->synopsis;
        $book->price = $request->price;
        if ($request->file('image') == null) {
            $book->image = $book->image;
        } else {
            $file = $request->file('image');
            $image = time()."_".$file->getClientOriginalName();
            Storage::putFileAs('public/images', $file, $image);
            Storage::delete('public/'.$book->image);
            $book->image = 'images/'.$image;
        }
        $book->save();
        foreach($book->bookgenres as $gd) $gd->delete();
        foreach ($request->genre as $g) {
            $bookgenre = new Bookgenre();
            $bookgenre->genre_id = $g;
            $bookgenre->book_id = $book->id;
            $bookgenre->save();
        }
        return redirect()->route('book-manage');
    }
    public function delete($id) {
        $book = Book::find($id);
        $orders = Order::where('book_id', '=', $book->id);
        foreach($book->bookgenres as $gd) $gd->delete();
        if (!($orders == null)) {
            foreach ($orders as $o) $o->delete();
        }
        Storage::delete('public/'.$book->image);
        $book->delete();

        return redirect()->route('book-manage');
    }
    public function validateBook($id) {
        $book = Book::find($id);
        if ($book == null) return redirect()->back();
        else return redirect()->route('book-view', $id);
    }
}
