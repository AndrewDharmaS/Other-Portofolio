<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\BookController;
use App\Http\Controllers\GenreController;
use App\Http\Controllers\OrderController;
use App\Http\Controllers\TransactionController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


Auth::routes();

Route::get('/', [HomeController::class, 'index'])->name('home');
Route::get('/bookView-{id}', [BookController::class, 'view'])->name('book-view');
Route::get('/validateBook-{id}', [BookController::class, 'validateBook'])->name('book-validate');
Route::get('/cart', [OrderController::class, 'cart'])->name('cart-view');
Route::get('/search', [BookController::class, 'search'])->name('search');


Route::group(['middleware' => ['auth']], function() {
    Route::get('/user-profile', [UserController::class, 'profile'])->name('user-profile');
    Route::post('/user-profile-update', [UserController::class, 'profileUpdate'])->name('user-profile-update');
    Route::get('/user-change-password', [UserController::class, 'changePasswordView'])->name('user-change-password');
    Route::post('/user-password-update', [UserController::class, 'changePassword'])->name('user-password-update');
});
// ---ADMIN---
Route::group(['middleware' => ['admin']], function() {
    Route::get('/manage-users', [UserController::class, 'manageUser'])->name('user-manage');
    Route::get('/user-update-{id}', [UserController::class, 'updateVIew'])->name('user-update-view');
    Route::post('/user-fresh-{id}', [UserController::class, 'update'])->name('user-update');
    Route::get('/user-delete-{id}', [UserController::class, 'delete'])->name('user-delete');
    
    Route::get('/manage-genres', [GenreController::class, 'manageGenre'])->name('genre-manage');
    Route::post('/genre-create', [GenreController::class, 'create'])->name('genre-create');
    Route::get('/genre-update-{id}', [GenreController::class, 'updateVIew'])->name('genre-update-view');
    Route::post('/genre-fresh-{id}', [GenreController::class, 'update'])->name('genre-update');
    Route::get('/genre-delete-{id}', [GenreController::class, 'delete'])->name('genre-delete');
    
    Route::get('/manage-books', [BookController::class, 'manageBook'])->name('book-manage');
    Route::post('/book-create', [BookController::class, 'create'])->name('book-create');
    Route::get('/book-update-{id}', [BookController::class, 'updateVIew'])->name('book-update-view');
    Route::post('/book-fresh-{id}', [BookController::class, 'update'])->name('book-update');
    Route::get('/book-delete-{id}', [BookController::class, 'delete'])->name('book-delete');
});
// ---MEMBER---
Route::group(['middleware' => ['member']], function() {

    Route::post('/order-create-{id}', [OrderController::class, 'create'])->name('order-create');
    Route::get('/order-update-{id}', [OrderController::class, 'updateVIew'])->name('order-update-view');
    Route::post('/order-fresh-{id}', [OrderController::class, 'update'])->name('order-update');
    Route::get('/order-delete-{id}', [OrderController::class, 'delete'])->name('order-delete');
    
    Route::get('/transaction-create', [TransactionController::class, 'create'])->name('transaction-create');
    Route::get('/transaction-view', [TransactionController::class, 'view'])->name('transaction-view');
    Route::get('/transaction-detail-{id}', [TransactionController::class, 'detail'])->name('transaction-detail');
});