@extends('layouts.main')
@push('css')
<link rel="stylesheet" href="{{asset('css/login.css')}}">
@endpush
@section('content')
<div class="container">
    <div class="content">
        <form method="POST" action="{{ route('login') }}">
            @csrf
            <div class="title">
                <h1>Login</h1>
            </div>
            <div class="input-group">
                <div class="input-group-prepend">
                    <span class="input-group-text" id="email">&#9993;</span>
                </div>
                <input type="email" name="email" class="form-control @error('email') is-invalid @enderror" placeholder="Email" aria-label="Email" aria-describedby="email" required>
                @error('email')
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                @enderror
            </div>
            <div class="input-group">
                <div class="input-group-prepend">
                    <span class="input-group-text" id="password">&#128274;</span>
                </div>
                <input type="password" name="password" class="form-control @error('password') is-invalid @enderror" placeholder="Password" aria-label="Password" aria-describedby="password" required>
                @error('password')
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                @enderror
            </div>
            
            <div class="row mb-3" style="padding: 10px;">
                <div class="col-md-6">
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" name="remember" id="remember" {{ old('remember') ? 'checked' : '' }}>

                        <label class="form-check-label" for="remember">
                            {{ __('Remember Me') }}
                        </label>
                    </div>
                </div>
            </div>
            <input type="submit" value="Login" class="btn btn-primary">
        </form>
    </div>
</div>
@endsection
