@extends('layouts.main')
@push('css')
<link rel="stylesheet" href="{{asset('css/profile.css')}}">
@endpush
@section('content')
<div class="container">
    <div class="update">
        <div class="title">
            Member's User Detail
        </div>
        <form action="{{ route('user-profile-update') }}" method="post">
            @csrf
            <div class="input-container">
                <label for="name">Name</label>
                <input type="text" name="name" id="name" class="form-control" value={{ $user->name }}>
            </div>
            <div class="input-container">
                <label>Email</label>
                <div class="text">{{ $user->email }}</div>
            </div>
            <div class="row">
                <div class="action">
                    <input type="submit" value="Update" class="btn btn-primary col-12">
                </div>
                <div class="action">
                    <a href="{{ route('user-change-password') }}" class="btn btn-primary col-12">Change Password</a>
                </div>
            </div>
        </form>
    </div>
</div>
@endsection
@push('js')
    
@endpush
