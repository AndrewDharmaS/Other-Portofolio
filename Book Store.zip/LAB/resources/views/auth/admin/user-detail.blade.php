@extends('layouts.main')
@push('css')
<link rel="stylesheet" href="{{asset('css/user-detail.css')}}">
@endpush
@section('content')
<div class="container">
    <div class="update">
        <div class="title">
            Member's User Detail
        </div>
        <form action="{{ route('user-update', $user->id) }}" method="post">
            @csrf
            <div class="input-container">
                <label for="name">Name</label>
                <input type="text" name="name" id="name" class="form-control" value="{{ $user->name }}">
            </div>
            <div class="input-container">
                <label for="email">Email</label>
                <input type="email" name="email" id="email" class="form-control" value="{{ $user->email }}">
            </div>
            <div class="input-container">
                <label for="role">Role</label>
                <select class="form-select form-control" name="role" id="role">
                    @if ($user->role == 'admin')
                        <option value="admin" selected>Admin</option>
                        <option value="member">Member</option>
                    @else
                        <option value="admin">Admin</option>
                        <option value="member" selected>Member</option>
                    @endif
                </select>
            </div>
            <input type="submit" value="Update" class="btn btn-primary">
        </form>
    </div>
</div>
@endsection
@push('js')
    
@endpush
