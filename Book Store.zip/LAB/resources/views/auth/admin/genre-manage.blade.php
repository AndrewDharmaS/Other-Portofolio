@extends('layouts.main')
@push('css')
<link rel="stylesheet" href="{{asset('css/genre-manage.css')}}">
@endpush
@section('content')
<div class="container">
    <div class="insert">
        <div class="title">
            Insert Genre Form
        </div>
        <form action="{{ route('genre-create') }}" method="post">
            @csrf
            <div class="input-container">
                <label for="name">Name</label>
                <input type="text" name="name" id="name" class="form-control">
            </div>
            <input type="submit" value="Insert" class="btn">
        </form>
    </div>
    <div class="content">
        @if ($genres->isEmpty())
        <div class="alert alert-danger">
            Genre is Empty
        </div>
        @else
        <table class="table">
            <thead>
                <tr>
                    <th scope="col">Name</th>
                    <th scope="col">Action</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($genres as $genre)
                    <tr>
                        <td scope="row">{{ $genre->name }}</td>
                        <td>
                            <a href="{{ route('genre-update-view', $genre->id) }}" class="btn btn-secondary">View Detail</a>
                            <a href="{{ route('genre-delete', $genre->id) }}" class="btn btn-danger">Delete</a>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
        @endif
    </div>
</div>
@endsection
@push('js')
    
@endpush
