@extends('layouts.main')
@push('css')
<link rel="stylesheet" href="{{asset('css/genre-detail.css')}}">
@endpush
@section('content')
<div class="container">
    <div class="update">
        <div class="title">
            Update Genre Form
        </div>
        <form action="{{ route('genre-update', $genre->id) }}" method="post">
            @csrf
            <div class="input-container">
                <label for="name">Name</label>
                <input type="text" name="name" id="name" class="form-control" value={{ $genre->name }}>
            </div>
            <input type="submit" value="Update" class="btn">
        </form>
        @if ($genre->bookgenres == null || $genre->bookgenres->isEmpty())
            <div class="alert alert-danger">
                No book with this genre.
            </div>
        @else

            <div class="title">
                Book List
            </div>
            <div class="content">
                <table class="table">
                    <thead>
                        <tr>
                            <th scope="col">Name</th>
                            <th scope="col">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($genre->bookgenres as $bg)
                            <tr>
                                <td scope="row">{{ $bg->book->name }}</td>
                                <td>
                                    <a href="{{ route('book-update-view', $bg->book->id) }}" class="btn btn-secondary">View Book Detail</a>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        @endif
    </div>
</div>
@endsection
@push('js')
    
@endpush
