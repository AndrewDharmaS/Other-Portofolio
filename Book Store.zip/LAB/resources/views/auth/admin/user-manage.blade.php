@extends('layouts.main')
@push('css')
<link rel="stylesheet" href="{{asset('css/user-manage.css')}}">
@endpush
@section('content')
<div class="container">
    <div class="content">
        <table class="table">
            <thead>
                <tr>
                    <th scope="col">Name</th>
                    <th scope="col">Email</th>
                    <th scope="col">Role</th>
                    <th scope="col">Action</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($users as $user)
                    <tr>
                        <td scope="row">{{ $user->name }}</td>
                        <td>{{ $user->email }}</td>
                        <td style="text-transform: capitalize;">{{ $user->role }}</td>
                        <td>
                            <a href="{{ route('user-update-view', $user->id) }}" class="btn btn-secondary">View Detail</a>
                            @if ($user->role != 'admin')
                                <a href="{{ route('user-delete', $user->id) }}" class="btn btn-danger">Delete</a>
                            @endif
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
</div>
@endsection
@push('js')
    
@endpush
