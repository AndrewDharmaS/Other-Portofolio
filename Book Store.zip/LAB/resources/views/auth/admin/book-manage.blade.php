@extends('layouts.main')
@push('css')
<link rel="stylesheet" href="{{asset('css/book-manage.css')}}">
@endpush
@section('content')
<div class="container">
    <div class="row content">
        <div class="col-12 title">
            Insert Book Form
        </div>
        <form action="{{ route('book-create') }}" class="col-12 padder" method="post" enctype="multipart/form-data">
            @csrf
            <div class="row">
                <div class="legend">
                    Name
                </div>
                <div class="text">
                    <input type="text" name="name" id="name" class="form-control">
                </div>
            </div>
            <div class="row">
                <div class="legend">
                    Author
                </div>
                <div class="text">
                    <input type="text" name="author" id="author" class="form-control">
                </div>
            </div>
            <div class="row">
                <div class="legend">
                    Synopsis
                </div>
                <div class="text">
                    <textarea name="synopsis" id="synopsis" cols="30" rows="15" class="form-control"></textarea>
                </div>
            </div>
            <div class="row">
                <div class="legend">
                    Genre(s)
                </div>
                <div class="text">
                    @foreach ($genres as $genre)
                        <div class="form-check form-check-inline col-3">
                            <input class="form-check-input" type="checkbox" name="genre[]" id="genre-{{ $genre->id }}" value="{{ $genre->id }}">
                            <label class="form-check-label" for="genre-{{ $genre->id }}">{{ $genre->name }}</label>
                        </div>
                    @endforeach
                    <div class="form-check form-check-inline col-12">
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="legend">
                    Price
                </div>
                <div class="text">
                    <input type="number" class="form-control" name="price" id="price">
                </div>
            </div>
            <div class="row">
                <div class="legend">
                    Image
                </div>
                <div class="file-input">
                    <input type="file" name="image" id="image" accept="image/*">
                </div>
            </div>
            <input type="submit" class="btn btn-primary" value="Insert">
        </form>
    </div>
    <div class="content">
        @if ($books->isEmpty())
        <div class="alert alert-danger">
            Book is Empty
        </div>
        @else
        <table class="table">
            <thead>
                <tr>
                    <th scope="col">Name</th>
                    <th scope="col">Author</th>
                    <th scope="col">Synopsis</th>
                    <th scope="col">Genre</th>
                    <th scope="col">Price</th>
                    <th scope="col">Action</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($books as $book)
                    <tr>
                        <td scope="row">{{ $book->name }}</td>
                        <td>{{ $book->author }}</td>
                        <td>{{ $book->synopsis}}</td>
                        <td>
                            @foreach ($book->bookgenres as $g)
                                {{ $g->genre->name }}<span class="genre-coma">,</span>
                            @endforeach
                        </td>
                        <td>{{ $book->price }}</td>
                        <td>
                            <a href="{{ route('book-update-view', $book->id) }}" class="btn btn-secondary">View Detail</a>
                            <a href="{{ route('book-delete', $book->id) }}" class="btn btn-danger">Delete</a>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
        @endif
    </div>
</div>
@endsection
@push('js')
    
@endpush
