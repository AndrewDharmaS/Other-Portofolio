@extends('layouts.main')
@push('css')
<link rel="stylesheet" href="{{asset('css/transaction-detail.css')}}">
@endpush
@section('content')
<div class="container">
    <div class="content">
        <table class="table">
            <thead>
                <tr>
                    <th scope="col">Book Name</th>
                    <th scope="col">Book Author</th>
                    <th scope="col">Price</th>
                    <th scope="col">Quantity</th>
                    <th scope="col">Sub Total</th>
                    <th scope="col">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $grandtotal = 0 ?>
                @foreach ($transaction->cart as $order)
                    <tr>
                        <td scope="row">{{ $order['name'] }}</td>
                        <td>{{ $order['author'] }}</td>
                        <td>{{ $order['price']}}</td>
                        <td>{{ $order['quantity']}} Book</td>
                        <td>IDR {{ $order['price'] * $order['quantity'] }}</td>
                        <?php $grandtotal += $order['price'] * $order['quantity'] ?>
                        <td>
                            <a href="{{ route('book-validate', $order['id'])}}" class="btn btn-secondary">View Book Detail</a>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
        <div class="total">
            Grand Total: IDR {{ $grandtotal }}
        </div>
    </div>
</div>
@endsection
@push('js')
    
@endpush
