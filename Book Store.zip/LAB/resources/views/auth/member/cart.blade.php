@extends('layouts.main')
@push('css')
<link rel="stylesheet" href="{{asset('css/cart.css')}}">
@endpush
@section('content')
<div class="container">
    <div class="content">
        @if ($orders == null || $orders->isEmpty())
            <div class="alert alert-danger">
                Cart is Empty!
            </div>
        @else
            <table class="table">
                <thead>
                    <tr>
                        <th scope="col">Book Name</th>
                        <th scope="col">Book Author</th>
                        <th scope="col">Price</th>
                        <th scope="col">Quantity</th>
                        <th scope="col">Sub Total</th>
                        <th scope="col">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $grandtotal = 0 ?>
                    @foreach ($orders as $order)
                        <?php $grandtotal += $order->book->price * $order->quantity ?>
                        <tr>
                            <td scope="row">{{ $order->book->name }}</td>
                            <td>{{ $order->book->author }}</td>
                            <td>{{ $order->book->price }}</td>
                            <td>{{ $order->quantity }}</td>
                            <td>{{ $order->book->price * $order->quantity }}</td>
                            <td>
                                <a href="{{ route('book-view', $order->book->id) }}" class="btn btn-secondary">View Book Detail</a>
                                <a href="{{ route('order-update-view', $order->id) }}" class="btn btn-primary">Edit</a>
                                <a href="{{ route('order-delete', $order->id) }}" class="btn btn-danger">Delete</a>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
            <div class="total">
                Grand Total: {{ $grandtotal }}
            </div>
            <a href="{{ route('transaction-create') }}" class="btn btn-primary checkout">Checkout</a>
        @endif
    </div>
</div>
@endsection
@push('js')
    
@endpush
