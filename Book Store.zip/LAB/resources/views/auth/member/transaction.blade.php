@extends('layouts.main')
@push('css')
<link rel="stylesheet" href="{{asset('css/transaction.css')}}">
@endpush
@section('content')
<div class="container">
    <div class="content">
        @if ($transactions->isEmpty())
            <div class="alert alert-danger">
                Transaction is Empty
            </div>
        @else
            <table class="table">
                <thead>
                    <tr>
                        <th scope="col">Transaction ID</th>
                        <th scope="col">Date</th>
                        <th scope="col">Action</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($transactions as $transaction)
                        <tr>
                            <td scope="row">{{ $transaction->transaction_id }}</td>
                            <td>{{ date_format($transaction->created_at, "D, M d, Y h:i A") }}</td>
                            <td>
                                <a href="{{ route('transaction-detail', $transaction->id) }}" class="btn btn-secondary">View Transaction Detail</a>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        @endif
    </div>
</div>
@endsection
@push('js')
    
@endpush
