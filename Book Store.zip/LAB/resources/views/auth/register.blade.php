@extends('layouts.main')
@push('css')
<link rel="stylesheet" href="{{asset('css/register.css')}}">
@endpush
@section('content')
<div class="container">
    <div class="content">
        <form method="POST" action="{{ route('register') }}">
            @csrf
            <div class="title">
                <h1>Register</h1>
            </div>
            <div class="input-group">
                <div class="input-group-prepend">
                    <span class="input-group-text" id="email">&#9993;</span>
                </div>
                <input type="email" name="email" class="form-control @error('email') is-invalid @enderror" placeholder="Email" aria-label="Email" aria-describedby="email">
                @error('email')
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                @enderror
            </div>
            <div class="input-group">
                <div class="input-group-prepend">
                    <span class="input-group-text" id="name">&#9737;</span>
                </div>
                <input type="name" name="name" class="form-control @error('name') is-invalid @enderror" placeholder="Name" aria-label="Name" aria-describedby="name">
                @error('name')
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                @enderror
            </div>
            <div class="input-group">
                <div class="input-group-prepend">
                    <span class="input-group-text" id="password">&#128274;</span>
                </div>
                <input type="password" name="password" class="form-control @error('password') is-invalid @enderror" placeholder="Password" aria-label="Password" aria-describedby="password">
                @error('password')
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                @enderror
            </div>
            <div class="input-group">
                <div class="input-group-prepend">
                    <span class="input-group-text" id="password-confirm">&#128274;</span>
                </div>
                <input type="password" name="password_confirmation" class="form-control @error('password-confirm') is-invalid @enderror" placeholder="Password Confirm" aria-label="Password-confirm" aria-describedby="password-confirm">
                @error('password-confirm')
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                @enderror
            </div>
            <input type="submit" value="Register" class="btn btn-primary">
        </form>
    </div>
</div>
@endsection
