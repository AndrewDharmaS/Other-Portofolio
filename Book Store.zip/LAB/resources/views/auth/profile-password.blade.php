@extends('layouts.main')
@push('css')
<link rel="stylesheet" href="{{asset('css/profile-password.css')}}">
@endpush
@section('content')
<div class="container">
    <div class="update">
        <div class="title">
            {{ Auth::user()->name }}'s User Detail
        </div>
        <form action="{{ route('user-password-update') }}" method="post">
            @csrf
            @if (session('status'))
                <div class="alert alert-danger">
                    {{ session('status') }}
                </div>
            @endif
            <div class="input-container">
                <label for="oldpassword">Old Password</label>
                <input type="password" name="oldpassword" id="oldpassword" class="form-control">
            </div>
            <div class="input-container">
                <label for="password">New Password</label>
                <input type="password" name="password" id="password" class="form-control">
            </div>
            <div class="input-container">
                <label for="password_confirm">New Confirmation Password</label>
                <input type="password" name="password_confirmation" id="password-confirm" class="form-control">
            </div>
            <input type="submit" value="Update" class="btn btn-primary">
        </form>
    </div>
</div>
@endsection
@push('js')
    
@endpush
