@extends('layouts.main')
@push('css')
<link rel="stylesheet" href="{{asset('css/index.css')}}">
@endpush
@section('content')
<div class="container">
    <div class="search-bar">
        <form action="{{ route('search') }}" method="get">
            @csrf
            <input type="search" name="search" id="search">
            <input type="submit" value="Search">
        </form>
        <a href="{{ route('home') }}" class="clear">Clear Filter</a>
    </div>
    <div class="row content">
        @if ($books == null || $books->isEmpty())
            <div class="alert alert-danger col-12">
                Book not Found
            </div>
        @else
            @foreach ($books as $book)
                <div class="book">
                    <div class="image">
                        <img src="{{ Storage::url($book->image) }}">
                    </div>
                    <div class="title">
                        {{ $book->name }}
                    </div>
                    <div class="author">
                        By {{ $book->author }}
                    </div>
                    <div class="price">
                        IDR {{ $book->price }}
                    </div>
                    @guest
                    <a href="{{ route('book-view', $book->id) }}" class="detail">&#9432; View Details</a>
                    @else
                        @if (Auth::user()->role =='member')
                            <a href="{{ route('book-view', $book->id) }}" class="detail">&#9432; View Details</a>
                        @elseif (Auth::user()->role =='admin')
                            <a href="{{ route('book-manage') }}" class="detail">&#9432; View Details</a>
                        @endif
                    @endguest
                </div>
            @endforeach
        @endif
    </div>
    <div class="pagination">
        {{$books->links()}}
    </div>
</div>
@endsection
@push('js')
    
@endpush
