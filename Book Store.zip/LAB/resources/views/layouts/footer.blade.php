<footer>
    <div class="footer">
        <div class="date" id="timestamp">
            Current date and time: {{ date('D, M d, Y h:i A')}}
        </div>
        <div class="cc">
            Copyright &copy; 2021 Book Store
        </div>
    </div>
</footer>