<header>
    <div class="navbar">
        <div class="logo">
            <a href="{{ route('home') }}">
                Book Store
            </a>
        </div>
        <div class="row nav-list">
            @guest
                @if (Route::has('register'))
                    <div class="link">
                        <a href="{{ route('register') }}">Register</a>
                    </div>
                @endif
                @if (Route::has('login'))
                    <div class="link">
                        <a href="{{ route('login') }}">Login</a>
                    </div>
                @endif
            @else
                @if (Auth::user()->role == 'admin')
                <div class="link dropdown">
                    <a class="dropdown-toggle" href="#" role="button" id="manageDropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        Manage
                    </a>
                    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="manageDropdown">
                        <a class="dropdown-item" href="{{ route('genre-manage') }}">Genres</a>
                        <a class="dropdown-item" href="{{ route('book-manage') }}">Books</a>
                        <a class="dropdown-item" href="{{ route('user-manage') }}">Users</a>
                    </div>
                </div>
                @elseif (Auth::user()->role == 'member')
                    <div class="link">
                        <a href="{{ route('cart-view') }}">View Cart</a>
                    </div>
                    <div class="link">
                        <a href="{{ route('transaction-view') }}">View Transaction History</a>
                    </div>
                @endif
                <div class="link dropdown">
                    <a class="dropdown-toggle" href="#" role="button" id="profileDropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        Hello, {{ Auth::user()->name }}
                    </a>
                    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="profileDropdown">
                        <a class="dropdown-item" href="{{ route('user-profile') }}">Profile</a>
                        <a class="dropdown-item" href="{{ route('logout') }}"
                            onclick="event.preventDefault();
                                            document.getElementById('logout-form').submit();">
                            {{ __('Logout') }}
                        </a>
                        <form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
                            @csrf
                        </form>
                    </div>
                </div>
            @endguest
        </div>
    </div>
</header>