@extends('layouts.main')
@push('css')
    <link rel="stylesheet" href="{{asset('css/book.css')}}">
@endpush
@section('content')
<div class="container">
    <div class="row content">
        <div class="col-12 title">
            {{ $book->name }}'s Book Detail
        </div>
        <div class="col-4 padder">
            <div class="image">
                <img src="{{ Storage::url($book->image) }}">
            </div>
        </div>
        <div class="col-8 padder">
            <div class="row">
                <div class="legend">
                    Name
                </div>
                <div class="text">
                    {{ $book->name }}    
                </div>
            </div>
            <div class="row">
                <div class="legend">
                    Author
                </div>
                <div class="text">
                    {{ $book->author }}    
                </div>
            </div>
            <div class="row">
                <div class="legend">
                    Synopsis
                </div>
                <div class="text">
                    {{ $book->synopsis }}
                </div>
            </div>
            <div class="row">
                <div class="legend">
                    Genre(s)
                </div>
                <div class="text">
                    @foreach ($book->bookgenres as $bg)
                        {{ $bg->genre->name }}<span class="genre-coma">,</span>
                    @endforeach
                </div>
            </div>
            <div class="row">
                <div class="legend">
                    Price
                </div>
                <div class="text">
                    IDR {{ $book->price }}
                </div>
            </div>
            @guest
            @else
            @if (Auth::user()->role == 'member')
                <div class="action">
                    <form action="{{ route('order-create', $book->id) }}" method="post">
                        @csrf
                        <div class="input-group">
                            <label class="input-group-prepend" for="quantity">
                                <div class="input-group-text">Quantity</div>
                            </label>
                            <input type="number" name="quantity" class="form-control" id="quantity" placeholder=". . ." min="1" value="1">
                        </div>
                        <input type="submit" value="Add to Cart">
                    </form>
                </div>
            @endif
            @endguest
        </div>
    </div>
</div>
@endsection
@push('js')
    
@endpush
