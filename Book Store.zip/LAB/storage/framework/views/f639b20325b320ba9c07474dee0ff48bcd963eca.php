<?php $__env->startPush('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/book-update.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row content">
        <div class="col-12 title">
            <?php echo e($book->name); ?>'s Book Detail
        </div>
        <form action="<?php echo e(route('book-update', $book->id)); ?>" class="col-12 padder" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="legend">
                    Name
                </div>
                <div class="text">
                    <input type="text" name="name" id="name" class="form-control" value="<?php echo e($book->name); ?>">
                </div>
            </div>
            <div class="row">
                <div class="legend">
                    Author
                </div>
                <div class="text">
                    <input type="text" name="author" id="author" class="form-control" value="<?php echo e($book->author); ?>">
                </div>
            </div>
            <div class="row">
                <div class="legend">
                    Synopsis
                </div>
                <div class="text">
                    <textarea name="synopsis" id="synopsis" cols="30" rows="15" class="form-control"><?php echo e($book->synopsis); ?></textarea>
                </div>
            </div>
            <div class="row">
                <div class="legend">
                    Genre(s)
                </div>
                <div class="text">
                    <?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="form-check form-check-inline col-3">
                            <?php if($book->bookgenres->contains('genre_id', $genre->id)): ?>
                                <input class="form-check-input" type="checkbox" name="genre[]" id="genre-<?php echo e($genre->id); ?>" value="<?php echo e($genre->id); ?>" checked>
                            <?php else: ?>
                                <input class="form-check-input" type="checkbox" name="genre[]" id="genre-<?php echo e($genre->id); ?>" value="<?php echo e($genre->id); ?>">
                            <?php endif; ?>
                            <label class="form-check-label" for="genre-<?php echo e($genre->id); ?>"><?php echo e($genre->name); ?></label>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div class="form-check form-check-inline col-12">
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="legend">
                    Price
                </div>
                <div class="text">
                    <input type="number" class="form-control" name="price" id="price" value="<?php echo e($book->price); ?>">
                </div>
            </div>
            <div class="row">
                <div class="legend">
                    Image
                </div>
                <div class="text">
                    <div class="image">
                        <img src="<?php echo e(Storage::url($book->image)); ?>">
                    </div>
                </div>
                <div class="file-input">
                    <input type="file" name="image" id="image" accept="image/*">
                </div>
            </div>
            <input type="submit" value="Update" class="btn btn-primary">
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
    
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Andrew\ANDREW_tugas\S5\PROJECT\WEBPROG\LAB\resources\views/auth/admin/book-update.blade.php ENDPATH**/ ?>