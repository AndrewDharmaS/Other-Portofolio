<?php $__env->startPush('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/cart.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="content">
        <?php if($orders == null || $orders->isEmpty()): ?>
            <div class="alert alert-danger">
                Cart is Empty!
            </div>
        <?php else: ?>
            <table class="table">
                <thead>
                    <tr>
                        <th scope="col">Book Name</th>
                        <th scope="col">Book Author</th>
                        <th scope="col">Price</th>
                        <th scope="col">Quantity</th>
                        <th scope="col">Sub Total</th>
                        <th scope="col">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $grandtotal = 0 ?>
                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $grandtotal += $order->book->price * $order->quantity ?>
                        <tr>
                            <td scope="row"><?php echo e($order->book->name); ?></td>
                            <td><?php echo e($order->book->author); ?></td>
                            <td><?php echo e($order->book->price); ?></td>
                            <td><?php echo e($order->quantity); ?></td>
                            <td><?php echo e($order->book->price * $order->quantity); ?></td>
                            <td>
                                <a href="<?php echo e(route('book-view', $order->book->id)); ?>" class="btn btn-secondary">View Book Detail</a>
                                <a href="<?php echo e(route('order-update-view', $order->id)); ?>" class="btn btn-primary">Edit</a>
                                <a href="<?php echo e(route('order-delete', $order->id)); ?>" class="btn btn-danger">Delete</a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <div class="total">
                Grand Total: <?php echo e($grandtotal); ?>

            </div>
            <a href="<?php echo e(route('transaction-create')); ?>" class="btn btn-primary checkout">Checkout</a>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
    
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Andrew\ANDREW_tugas\S5\PROJECT\WEBPROG\LAB\resources\views/auth/member/cart.blade.php ENDPATH**/ ?>