<?php $__env->startPush('css'); ?>
    
<?php $__env->stopPush(); ?>
<style>
    .container {
        padding: 75px 0;
    }
    .container > .content {
        margin: 0;
    }
    .container > .update {
        width: 100%;
        border: 1px solid var(--gray-color);
        padding: 20px;
    }
    .container > .update > .title {
        font-size: 24px;
        margin-bottom: 10px;
    }
    .container > .update > form {
        margin-bottom: 20px;
    }
    .container > .update > form > input[type=submit] {
        width: 100%;
    }
    .container > .update > form > .input-container {
        display: flex;
        margin-bottom: 20px;
    }
    .container > .update > form > .input-container label {
        width: 25%;
        display: block;
        line-height: 2rem;
    }
    .container > .update > form > .input-container input,
    .container > .update > form > .input-container select {
        width: 75%;
    }
    .container > .update .content {
        width: 100%;
    }
    .container > .update .content table thead tr th {
        border-top: 0;
        border-bottom: 1px solid var(--black-color);
    }
    .container > .update .content table td {
        vertical-align: middle;
    }
</style>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="update">
        <div class="title">
            Member's User Detail
        </div>
        <form action="">
            <div class="input-container">
                <label for="oldpassword">Old Password</label>
                <input type="password" name="oldpassword" id="oldpassword" class="form-control">
            </div>
            <div class="input-container">
                <label for="password">New Password</label>
                <input type="password" name="password" id="password" class="form-control">
            </div>
            <div class="input-container">
                <label for="password_confirm">New Confirmation Password</label>
                <input type="password" name="password-confirm" id="password-confirm" class="form-control">
            </div>
            <input type="submit" value="Update" class="btn btn-primary">
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
    
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Andrew\ANDREW_tugas\S5\PROJECT\WEBPROG\LAB\resources\views/profile-forgot.blade.php ENDPATH**/ ?>