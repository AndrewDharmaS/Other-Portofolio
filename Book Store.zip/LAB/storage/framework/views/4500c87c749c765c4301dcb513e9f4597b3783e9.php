<?php $__env->startPush('css'); ?>
    
<?php $__env->stopPush(); ?>
<style>
    .container {
        padding: 75px 0;
    }
    .container > .content {
        margin: 0;
    }
    .container > .content {
        width: 100%;
        border: 1px solid var(--gray-color);
        padding: 20px;
    }
    .container > .content > .title {
        font-size: 24px;
        text-transform: uppercase;
        text-align: center;
        font-weight: 700;
    }
    .container > .content > .padder {
        padding: 25px;
    }
    .container > .content > .padder > .row {
        margin: 0;
        margin-bottom: 20px;
    }
    .container > .content > .padder .legend {
        width: 30%;
        align-self: center;
    }
    .container > .content > .padder .text {
        width: 60%;
        text-align: justify;
    }
    .container > .content > .padder .image {
        width: auto;
        max-height: 400px;
    }
    .container > .content > .padder .image > img {
        width: auto;
        height: 100%;
    }
    .container > .content > .padder .action {
        
    }
    .container > .content > .padder .file-input {
        background-color: var(--white-color);
        margin-left: 30%;
        margin-top: 20px;
        width: 60%;
    }
    .container > .content > .padder .file-input > input[type=file] {
        background-color: var(--white-color);
        border: 1px solid var(--gray-color);
        border-radius: 2px;
        height: calc(1.5em + 0.75rem + 2px);
        width: 100%;
    }
    .container > .content > .padder .file-input > input[type=file]::-webkit-file-upload-button {
        visibility: hidden;
        display: none;
    }
    .container > .content > .padder .file-input > input[type=file]::before {
        content: 'Choose File';
        display: inline-block;
        background: rgb(240, 240, 240);
        border-right: 1px solid var(--gray-color);
        border-top-left-radius: 2px;
        border-bottom-left-radius: 2px;
        padding: .375rem 0.75rem;
        outline: none;
        white-space: nowrap;
        cursor: pointer;
        margin-right: 15px;
    }
    input[type=number] {
        -moz-appearance: textfield;
    }
    input::-webkit-outer-spin-button,
    input::-webkit-inner-spin-button {
        -webkit-appearance: none;
        margin: 0;
    }
    .container > .content > .padder .action > form > input[type=submit] {
        margin-lefT: auto;
        border: 1px solid var(--theme-color);
        color: var(--white-color);
        background-color: var(--theme-color);
        padding: .375rem 0.75rem;
        height: calc(1.5em + 0.75rem + 2px);
        transition: all 0.3s;
        border-radius: 2px;
    }
    .container > .content > .padder .action > form > input[type=submit]:hover {
        color: var(--theme-color);
        background-color: var(--white-color);
        transition: all 0.15s;
    }
</style>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row content">
        <div class="col-12 title">
            Harry Potter series's Book Detail
        </div>
        <form action="" class="col-12 padder" method="post">
            <div class="row">
                <div class="legend">
                    Name
                </div>
                <div class="text">
                    <input type="text" name="name" id="name" class="form-control">
                </div>
            </div>
            <div class="row">
                <div class="legend">
                    Author
                </div>
                <div class="text">
                    <input type="text" name="author" id="author" class="form-control">
                </div>
            </div>
            <div class="row">
                <div class="legend">
                    Synopsis
                </div>
                <div class="text">
                    <textarea name="synopsis" id="synopsis" cols="30" rows="15" class="form-control"></textarea>
                </div>
            </div>
            <div class="row">
                <div class="legend">
                    Genre(s)
                </div>
                <div class="text">
                    <div class="form-check form-check-inline col-3">
                        <input class="form-check-input" type="checkbox" id="checkbox" value="option1">
                        <label class="form-check-label" for="checkbox">1</label>
                    </div>
                    <div class="form-check form-check-inline col-12">
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="legend">
                    Price
                </div>
                <div class="text">
                    <input type="number" class="form-control" name="" id="">
                </div>
            </div>
            <div class="row">
                <div class="legend">
                    Image
                </div>
                <div class="text">
                    <div class="image">
                        <img src="https://images-na.ssl-images-amazon.com/images/I/81WUAoL-wFL.jpg">
                    </div>
                </div>
                <div class="file-input">
                    <input type="file" name="" id="">
                </div>
            </div>
            <input type="submit" value="Update">
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
    
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Andrew\ANDREW_tugas\S5\PROJECT\WEBPROG\LAB\resources\views/update-book.blade.php ENDPATH**/ ?>