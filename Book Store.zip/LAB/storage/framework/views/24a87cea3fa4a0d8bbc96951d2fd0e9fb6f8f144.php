<?php $__env->startPush('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/profile-password.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="update">
        <div class="title">
            <?php echo e(Auth::user()->name); ?>'s User Detail
        </div>
        <form action="<?php echo e(route('user-password-update')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <?php if(session('status')): ?>
                <div class="alert alert-danger">
                    <?php echo e(session('status')); ?>

                </div>
            <?php endif; ?>
            <div class="input-container">
                <label for="oldpassword">Old Password</label>
                <input type="password" name="oldpassword" id="oldpassword" class="form-control">
            </div>
            <div class="input-container">
                <label for="password">New Password</label>
                <input type="password" name="password" id="password" class="form-control">
            </div>
            <div class="input-container">
                <label for="password_confirm">New Confirmation Password</label>
                <input type="password" name="password_confirmation" id="password-confirm" class="form-control">
            </div>
            <input type="submit" value="Update" class="btn btn-primary">
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
    
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Andrew\ANDREW_tugas\S5\PROJECT\WEBPROG\LAB\resources\views/auth/profile-password.blade.php ENDPATH**/ ?>