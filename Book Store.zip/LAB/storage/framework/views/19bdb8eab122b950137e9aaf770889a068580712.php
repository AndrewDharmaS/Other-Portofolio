<?php $__env->startPush('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/genre-manage.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="insert">
        <div class="title">
            Insert Genre Form
        </div>
        <form action="<?php echo e(route('genre-create')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="input-container">
                <label for="name">Name</label>
                <input type="text" name="name" id="name" class="form-control">
            </div>
            <input type="submit" value="Insert" class="btn">
        </form>
    </div>
    <div class="content">
        <?php if($genres->isEmpty()): ?>
        <div class="alert alert-danger">
            Genre is Empty
        </div>
        <?php else: ?>
        <table class="table">
            <thead>
                <tr>
                    <th scope="col">Name</th>
                    <th scope="col">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td scope="row"><?php echo e($genre->name); ?></td>
                        <td>
                            <a href="<?php echo e(route('genre-update-view', $genre->id)); ?>" class="btn btn-secondary">View Detail</a>
                            <a href="<?php echo e(route('genre-delete', $genre->id)); ?>" class="btn btn-danger">Delete</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
    
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Andrew\Desktop\TEST\LAB\resources\views/auth/admin/genre-manage.blade.php ENDPATH**/ ?>