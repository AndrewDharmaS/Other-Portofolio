<?php $__env->startPush('css'); ?>
    
<?php $__env->stopPush(); ?>
<style>
    .container {
        padding: 75px 0;
    }
    .container > .content {
        margin: 0;
    }
    .container > .content {
        width: 100%;
        border: 1px solid var(--gray-color);
        padding: 20px;
    }
    .container > .content > .title {
        font-size: 24px;
        text-transform: uppercase;
        text-align: center;
        font-weight: 700;
    }
    .container > .content > .padder {
        padding: 25px;
    }
    .container > .content > .padder .image {
        width: 100%;
    }
    .container > .content > .padder .image > img {
        width: 100%;
        height: auto;
    }
    .container > .content > .padder > .row {
        margin: 0;
        margin-bottom: 20px;
    }
    .container > .content > .padder .legend {
        width: 30%;
        align-self: center;
    }
    .container > .content > .padder .text {
        width: 60%;
        text-align: justify;
    }
    .container > .content > .padder .action {
        
    }
    .container > .content > .padder .action > form {
        display: flex;
    }
    .container > .content > .padder .action > form > .input-group {
        max-width: 50%;
    }
    .container > .content > .padder .action > form > input[type=number] {
        -moz-appearance: textfield;
    }
    .container > .content > .padder .action > form input::-webkit-outer-spin-button,
    .container > .content > .padder .action > form input::-webkit-inner-spin-button {
        -webkit-appearance: none;
        margin: 0;
    }

    .container > .content > .padder .action > form > input[type=submit] {
        margin-lefT: auto;
        border: 1px solid var(--theme-color);
        color: var(--white-color);
        background-color: var(--theme-color);
        padding: .375rem 0.75rem;
        height: calc(1.5em + 0.75rem + 2px);
        transition: all 0.3s;
        border-radius: 2px;
    }
    .container > .content > .padder .action > form > input[type=submit]:hover {
        color: var(--theme-color);
        background-color: var(--white-color);
        transition: all 0.15s;
    }
    .container > .content .genre-coma:last-child {
        display: none;
    }
</style>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row content">
        <div class="col-12 title">
            <?php echo e($order->book->name); ?>'s Book Detail
        </div>
        <div class="col-4 padder">
            <div class="image">
                <img src="https://images-na.ssl-images-amazon.com/images/I/81WUAoL-wFL.jpg">
            </div>
        </div>
        <div class="col-8 padder">
            <div class="row">
                <div class="legend">
                    Name
                </div>
                <div class="text">
                    <?php echo e($order->book->name); ?>    
                </div>
            </div>
            <div class="row">
                <div class="legend">
                    Author
                </div>
                <div class="text">
                    <?php echo e($order->book->author); ?>    
                </div>
            </div>
            <div class="row">
                <div class="legend">
                    Synopsis
                </div>
                <div class="text">
                    <?php echo e($order->book->synopsis); ?>

                </div>
            </div>
            <div class="row">
                <div class="legend">
                    Genre(s)
                </div>
                <div class="text">
                    <?php $__currentLoopData = $order->book->bookgenres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($bg->genre->name); ?><span class="genre-coma">,</span>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <div class="row">
                <div class="legend">
                    Price
                </div>
                <div class="text">
                    IDR <?php echo e($order->book->price); ?>

                </div>
            </div>
            <div class="action">
                <form action="<?php echo e(route('order-update', $order->id)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="input-group">
                        <label class="input-group-prepend" for="quantity">
                            <div class="input-group-text">Quantity</div>
                        </label>
                        <input type="number" name="quantity" class="form-control" id="quantity" placeholder=". . ." min="1" value="<?php echo e($order->quantity); ?>">
                    </div>
                    <input type="submit" value="Update">
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
    
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Andrew\ANDREW_tugas\S5\PROJECT\WEBPROG\LAB\resources\views/auth/member/order-update.blade.php ENDPATH**/ ?>