<?php $__env->startPush('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/genre-detail.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="update">
        <div class="title">
            Update Genre Form
        </div>
        <form action="<?php echo e(route('genre-update', $genre->id)); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="input-container">
                <label for="name">Name</label>
                <input type="text" name="name" id="name" class="form-control" value=<?php echo e($genre->name); ?>>
            </div>
            <input type="submit" value="Update" class="btn">
        </form>
        <?php if($genre->bookgenres == null || $genre->bookgenres->isEmpty()): ?>
            <div class="alert alert-danger">
                No book with this genre.
            </div>
        <?php else: ?>

            <div class="title">
                Book List
            </div>
            <div class="content">
                <table class="table">
                    <thead>
                        <tr>
                            <th scope="col">Name</th>
                            <th scope="col">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $genre->bookgenres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td scope="row"><?php echo e($bg->book->name); ?></td>
                                <td>
                                    <a href="<?php echo e(route('book-update-view', $bg->book->id)); ?>" class="btn btn-secondary">View Book Detail</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
    
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Andrew\ANDREW_tugas\S5\PROJECT\WEBPROG\LAB\resources\views/auth/admin/genre-detail.blade.php ENDPATH**/ ?>