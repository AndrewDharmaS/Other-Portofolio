<?php $__env->startPush('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/profile.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="update">
        <div class="title">
            Member's User Detail
        </div>
        <form action="<?php echo e(route('user-profile-update')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="input-container">
                <label for="name">Name</label>
                <input type="text" name="name" id="name" class="form-control" value=<?php echo e($user->name); ?>>
            </div>
            <div class="input-container">
                <label>Email</label>
                <div class="text"><?php echo e($user->email); ?></div>
            </div>
            <div class="row">
                <div class="action">
                    <input type="submit" value="Update" class="btn btn-primary col-12">
                </div>
                <div class="action">
                    <a href="<?php echo e(route('user-change-password')); ?>" class="btn btn-primary col-12">Change Password</a>
                </div>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
    
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Andrew\ANDREW_tugas\S5\PROJECT\WEBPROG\LAB\resources\views/auth/profile.blade.php ENDPATH**/ ?>