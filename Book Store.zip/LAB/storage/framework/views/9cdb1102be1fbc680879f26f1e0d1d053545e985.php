<?php $__env->startPush('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/user-detail.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="update">
        <div class="title">
            Member's User Detail
        </div>
        <form action="<?php echo e(route('user-update', $user->id)); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="input-container">
                <label for="name">Name</label>
                <input type="text" name="name" id="name" class="form-control" value="<?php echo e($user->name); ?>">
            </div>
            <div class="input-container">
                <label for="email">Email</label>
                <input type="email" name="email" id="email" class="form-control" value="<?php echo e($user->email); ?>">
            </div>
            <div class="input-container">
                <label for="role">Role</label>
                <select class="form-select form-control" name="role" id="role">
                    <?php if($user->role == 'admin'): ?>
                        <option value="admin" selected>Admin</option>
                        <option value="member">Member</option>
                    <?php else: ?>
                        <option value="admin">Admin</option>
                        <option value="member" selected>Member</option>
                    <?php endif; ?>
                </select>
            </div>
            <input type="submit" value="Update" class="btn btn-primary">
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
    
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Andrew\ANDREW_tugas\S5\PROJECT\WEBPROG\LAB\resources\views/auth/admin/user-detail.blade.php ENDPATH**/ ?>