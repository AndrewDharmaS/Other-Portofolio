<footer>
    <div class="footer">
        <div class="date" id="timestamp">
            Current date and time: <?php echo e(date('D, M d, Y h:i A')); ?>

        </div>
        <div class="cc">
            Copyright &copy; 2021 Book Store
        </div>
    </div>
</footer><?php /**PATH C:\Users\Andrew\Desktop\TEST\LAB\resources\views/layouts/footer.blade.php ENDPATH**/ ?>