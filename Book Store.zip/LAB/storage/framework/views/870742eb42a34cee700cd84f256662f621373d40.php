<header>
    <div class="navbar">
        <div class="logo">
            <a href="<?php echo e(route('home')); ?>">
                Book Store
            </a>
        </div>
        <div class="row nav-list">
            <?php if(auth()->guard()->guest()): ?>
                <?php if(Route::has('register')): ?>
                    <div class="link">
                        <a href="<?php echo e(route('register')); ?>">Register</a>
                    </div>
                <?php endif; ?>
                <?php if(Route::has('login')): ?>
                    <div class="link">
                        <a href="<?php echo e(route('login')); ?>">Login</a>
                    </div>
                <?php endif; ?>
            <?php else: ?>
                <?php if(Auth::user()->role == 'admin'): ?>
                <div class="link dropdown">
                    <a class="dropdown-toggle" href="#" role="button" id="manageDropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        Manage
                    </a>
                    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="manageDropdown">
                        <a class="dropdown-item" href="<?php echo e(route('genre-manage')); ?>">Genres</a>
                        <a class="dropdown-item" href="<?php echo e(route('book-manage')); ?>">Books</a>
                        <a class="dropdown-item" href="<?php echo e(route('user-manage')); ?>">Users</a>
                    </div>
                </div>
                <?php elseif(Auth::user()->role == 'member'): ?>
                    <div class="link">
                        <a href="<?php echo e(route('cart-view')); ?>">View Cart</a>
                    </div>
                    <div class="link">
                        <a href="<?php echo e(route('transaction-view')); ?>">View Transaction History</a>
                    </div>
                <?php endif; ?>
                <div class="link dropdown">
                    <a class="dropdown-toggle" href="#" role="button" id="profileDropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        Hello, <?php echo e(Auth::user()->name); ?>

                    </a>
                    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="profileDropdown">
                        <a class="dropdown-item" href="<?php echo e(route('user-profile')); ?>">Profile</a>
                        <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                            onclick="event.preventDefault();
                                            document.getElementById('logout-form').submit();">
                            <?php echo e(__('Logout')); ?>

                        </a>
                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                            <?php echo csrf_field(); ?>
                        </form>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</header><?php /**PATH C:\Users\Andrew\Desktop\TEST\LAB\resources\views/layouts/header.blade.php ENDPATH**/ ?>