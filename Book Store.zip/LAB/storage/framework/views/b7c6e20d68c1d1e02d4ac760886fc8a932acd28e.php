<?php $__env->startPush('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/transaction.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="content">
        <?php if($transactions->isEmpty()): ?>
            <div class="alert alert-danger">
                Transaction is Empty
            </div>
        <?php else: ?>
            <table class="table">
                <thead>
                    <tr>
                        <th scope="col">Transaction ID</th>
                        <th scope="col">Date</th>
                        <th scope="col">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td scope="row"><?php echo e($transaction->transaction_id); ?></td>
                            <td><?php echo e(date_format($transaction->created_at, "D, M d, Y h:i A")); ?></td>
                            <td>
                                <a href="<?php echo e(route('transaction-detail', $transaction->id)); ?>" class="btn btn-secondary">View Transaction Detail</a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
    
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Andrew\ANDREW_tugas\S5\PROJECT\WEBPROG\LAB\resources\views/auth/member/transaction.blade.php ENDPATH**/ ?>