<?php $__env->startPush('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/user-manage.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="content">
        <table class="table">
            <thead>
                <tr>
                    <th scope="col">Name</th>
                    <th scope="col">Email</th>
                    <th scope="col">Role</th>
                    <th scope="col">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td scope="row"><?php echo e($user->name); ?></td>
                        <td><?php echo e($user->email); ?></td>
                        <td style="text-transform: capitalize;"><?php echo e($user->role); ?></td>
                        <td>
                            <a href="<?php echo e(route('user-update-view', $user->id)); ?>" class="btn btn-secondary">View Detail</a>
                            <?php if($user->role != 'admin'): ?>
                                <a href="<?php echo e(route('user-delete', $user->id)); ?>" class="btn btn-danger">Delete</a>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
    
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Andrew\Desktop\TEST\LAB\resources\views/auth/admin/user-manage.blade.php ENDPATH**/ ?>