<?php $__env->startPush('css'); ?>
    
<?php $__env->stopPush(); ?>
<style>
    .container {
        padding-top: 25px;
        padding-bottom: 75px;
    }
    .container > .content {
        margin: 0;
    }
    .container > .content {
        width: 100%;
    }
    .container > .content table thead tr th {
        border-top: 0;
        border-bottom: 1px solid var(--black-color);
    }
</style>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="content">
        <table class="table">
            <thead>
                <tr>
                    <th scope="col">Name</th>
                    <th scope="col">Email</th>
                    <th scope="col">Role</th>
                    <th scope="col">Action</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td scope="row">NAMAAA</td>
                    <td>EMAIL@EMIAL</td>
                    <td>ADMIN</td>
                    <td>
                        <a href="" class="btn btn-secondary">View Detail</a>
                        <a href="" class="btn btn-danger">Delete</a>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
    
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Andrew\ANDREW_tugas\S5\PROJECT\WEBPROG\LAB\resources\views/user-manage.blade.php ENDPATH**/ ?>