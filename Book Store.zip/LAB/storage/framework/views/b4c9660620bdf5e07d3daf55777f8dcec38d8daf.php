<?php $__env->startPush('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/search.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="search-bar">
        <form action="<?php echo e(route('search')); ?>" method="get">
            <?php echo csrf_field(); ?>
            <input type="search" name="search" id="search" value="<?php echo e($search); ?>">
            <input type="submit" value="Search">
        </form>
        <a href="<?php echo e(route('home')); ?>" class="clear">Clear Filter</a>
    </div>
    <div class="row content">
        <?php if($books == null || $books->isEmpty()): ?>
            <div class="alert alert-danger col-12">
                Book not Found
            </div>
        <?php else: ?>
            <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="book">
                <div class="image">
                    <img src="<?php echo e(Storage::url($book->image)); ?>">
                </div>
                <div class="title">
                    <?php echo e($book->name); ?>

                </div>
                <div class="author">
                    By <?php echo e($book->author); ?>

                </div>
                <div class="price">
                    IDR <?php echo e($book->price); ?>

                </div>
                <a href="<?php echo e(route('book-view', $book->id)); ?>" class="detail">&#9432; View Details</a>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </div>
    <div class="pagination">
        <?php echo e($books->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
    
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Andrew\Desktop\TEST\LAB\resources\views/search.blade.php ENDPATH**/ ?>