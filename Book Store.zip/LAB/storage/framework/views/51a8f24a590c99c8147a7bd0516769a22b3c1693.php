<?php $__env->startPush('css'); ?>
    
<?php $__env->stopPush(); ?>
<style>
    .container {
        padding-top: 25px;
        padding-bottom: 75px;
    }
    .container > .content {
        margin: 0;
    }
    .container > .content {
        width: 100%;
    }
    .container > .content table thead tr th {
        border-top: 0;
        border-bottom: 1px solid var(--black-color);
    }
    .container > .content .total {
        font-weight: 700;
    }
    .container > .content table td {
        vertical-align: middle;
    }
    .container > .content .checkout {
        margin-top: 20px;
    }
</style>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="content">
        <table class="table">
            <thead>
                <tr>
                    <th scope="col">Book Name</th>
                    <th scope="col">Book Author</th>
                    <th scope="col">Price</th>
                    <th scope="col">Quantity</th>
                    <th scope="col">Sub Total</th>
                    <th scope="col">Action</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td scope="row">NAMAAA</td>
                    <td>EMAIL@EMIAL</td>
                    <td>ADMIN</td>
                    <td>ADMIN</td>
                    <td>ADMIN</td>
                    <td>
                        <a href="" class="btn btn-secondary">View Book Detail</a>
                        <a href="" class="btn btn-primary">Edit</a>
                        <a href="" class="btn btn-danger">Delete</a>
                    </td>
                </tr>
            </tbody>
        </table>
        <div class="total">
            Grand Total: IDR 1203912
        </div>
        <a href="" class="btn btn-primary checkout">Checkout</a>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
    
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Andrew\ANDREW_tugas\S5\PROJECT\WEBPROG\LAB\resources\views/cart.blade.php ENDPATH**/ ?>