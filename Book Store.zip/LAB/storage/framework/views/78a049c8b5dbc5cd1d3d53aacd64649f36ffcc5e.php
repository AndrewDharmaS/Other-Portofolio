<?php $__env->startPush('css'); ?>
    
<?php $__env->stopPush(); ?>
<style>
    .container {
        padding: 75px 0;
    }
    .container > .content {
        margin: 0;
    }
    .container > .update {
        width: 100%;
        border: 1px solid var(--gray-color);
        padding: 20px;
    }
    .container > .update > .title {
        font-size: 24px;
        margin-bottom: 10px;
    }
    .container > .update > form {
        margin-bottom: 20px;
    }
    .container > .update > form > input[type=submit] {
        width: 100%;
        background-color: var(--theme-color);
        border: 1px solid var(--theme-color);
        border-radius: 2px;
        color: var(--white-color);
    }
    .container > .update > form > input[type=submit]:hover {
        background-color: var(--white-color);
        color: var(--theme-color);
    }
    .container > .update > form > .input-container {
        display: flex;
        margin-bottom: 20px;
    }
    .container > .update > form > .input-container label {
        width: 25%;
        display: block;
        line-height: 2rem;
    }
    .container > .update > form > .input-container input {
        width: 75%;
    }
    .container > .update .content {
        width: 100%;
    }
    .container > .update .content table thead tr th {
        border-top: 0;
        border-bottom: 1px solid var(--black-color);
    }
</style>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="update">
        <div class="title">
            Update Genre Form
        </div>
        <form action="">
            <div class="input-container">
                <label for="name">Name</label>
                <input type="text" name="name" id="name" class="form-control">
            </div>
            <input type="submit" value="Update" class="btn">
        </form>
        <div class="title">
            Book List
        </div>
        <div class="content">
            <table class="table">
                <thead>
                    <tr>
                        <th scope="col">Name</th>
                        <th scope="col">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td scope="row">NAMAAA</td>
                        <td>
                            <a href="" class="btn btn-secondary">View Book Detail</a>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
    
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Andrew\ANDREW_tugas\S5\PROJECT\WEBPROG\LAB\resources\views/genre-detail.blade.php ENDPATH**/ ?>