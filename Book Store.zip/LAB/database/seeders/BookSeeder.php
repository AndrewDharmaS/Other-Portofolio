<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Faker\Factory as Faker;

class BookSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // $faker = Faker::create('id_ID');
 
    	// for($i = 1; $i <= 20; $i++){

        //     DB::table('books')->insert([
        //         'name' => $faker->name,
        //         'author' => $faker->jobTitle,
        //         'synopsis' => 'yes',
        //         'price' => $faker->numberBetween(100, 50000),
        //         'image' => 'a'
        //     ]);
        // }
    	// for($i = 1; $i <= 20; $i++){

        //     DB::table('books')->insert([
        //         'name' => $faker->name,
        //         'author' => $faker->jobTitle,
        //         'synopsis' => 'no',
        //         'price' => $faker->numberBetween(100, 50000),
        //         'image' => 'a'
        //     ]);
        // }
    }
}
